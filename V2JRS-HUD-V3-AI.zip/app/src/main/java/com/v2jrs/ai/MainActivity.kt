package com.v2jrs.ai

import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import org.json.JSONArray
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import androidx.compose.ui.text.input.PasswordVisualTransformation
import java.util.Locale

class MainActivity: ComponentActivity() {
 private var heard by mutableStateOf("")
 private var voiceError by mutableStateOf("")
 private var tts: TextToSpeech? = null
 private var ready by mutableStateOf(false)
 private val mic = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
  heard = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
 }
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  tts = TextToSpeech(this) { status -> if(status == TextToSpeech.SUCCESS) { ready = (tts?.setLanguage(Locale("tr","TR")) ?: -2) >= 0 } }
  setContent { Hud() }
 }
 override fun onDestroy(){ tts?.shutdown(); super.onDestroy() }
 private fun listen(){ voiceError=""; try { mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,"tr-TR")) } catch(e:Exception){ voiceError="Ses tanıma kullanılamıyor. Metinle devam et." } }
 @Composable fun Hud(){
  val cyan=Color(0xFF38E8FF); val yellow=Color(0xFFFFD740); val bg=Color(0xFF07101B)
  var input by remember { mutableStateOf("") }; var stage by remember { mutableStateOf(0) }; var target by remember { mutableStateOf(false) }; var auto by remember { mutableStateOf(false) }; var voice by remember { mutableStateOf(true) }; var rate by remember { mutableStateOf(1f) }; var pitch by remember { mutableStateOf(1f) }; var settings by remember { mutableStateOf(false) }; var energy by remember { mutableStateOf(100) }; var log by remember { mutableStateOf(listOf("Sistem başlatıldı. Sarı alan keşfe hazır.")) }
  val scope=rememberCoroutineScope()
  var apiKey by remember { mutableStateOf("") }
  var model by remember { mutableStateOf("openrouter/free") }
  var busy by remember { mutableStateOf(false) }
  var history by remember { mutableStateOf(listOf<Pair<String,String>>()) }
  val stories=listOf("Bölüm 1 • Sinyal keşfi","Bölüm 2 • Veri akışı","Bölüm 3 • Anomali analizi","Bölüm 4 • Sistem dengelendi")
  fun say(s:String){ log=(log+s).takeLast(30); if(voice && ready){tts?.setSpeechRate(rate);tts?.setPitch(pitch);tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"hud")} }
  fun advance(){ if(stage==3){say("Hikâye tamamlandı. Sistem hazır.");return}; target=true; stage=(stage+1).coerceAtMost(3); energy=(energy-8).coerceAtLeast(0); say(listOf("Sarı alana ulaşılıyor. Veri akışı başlıyor.","Anomali tespit edildi. Sanal sistem analiz ediliyor.","Analiz tamamlandı. Sistem dengelendi.")[stage.coerceAtLeast(1)-1]) }
  fun command(q:String){ if(q.isBlank())return; log=(log+"Sen: $q").takeLast(30); val s=q.lowercase(Locale("tr","TR")); when { "sarı" in s || "hikaye" in s || "hikâye" in s -> advance(); "otonom" in s -> {auto=!auto;say(if(auto)"Otonom mod açık." else "Otonom mod kapalı.")}; "enerji" in s -> {energy=100;say("Sanal enerji yenilendi.")}; "merhaba" in s -> say("Merhaba. V2JRS sistemleri hazır."); else -> {
   if(apiKey.isBlank()){say("Gerçek AI için Ayarlar bölümüne OpenRouter API anahtarını gir.");return}
   if(busy){say("Önceki yanıt hazırlanıyor.");return}
   busy=true; val key=apiKey.trim(); val selected=model.trim(); val context=history.takeLast(12)
   scope.launch { try {
    val answer=withContext(Dispatchers.IO){askAI(key,selected,context,q)}
    history=(history+listOf("user" to q,"assistant" to answer)).takeLast(24);say(answer)
   } catch(e:Exception){say("AI bağlantısı başarısız: ${e.message ?: "Bağlantı hatası"}")} finally {busy=false} }
  } } }
  LaunchedEffect(heard){if(heard.isNotBlank()){command(heard);heard=""}}
  LaunchedEffect(auto){while(auto){delay(9000);target=!target;energy=(energy+3).coerceAtMost(100);say("Otonom tarama: sanal sistem kontrol edildi.")}}
  val x by animateFloatAsState(if(target) .77f else .25f, tween(900),label="move")
  val pulse by rememberInfiniteTransition(label="pulse").animateFloat(.75f,1.2f,infiniteRepeatable(tween(1000),RepeatMode.Reverse),label="ring")
  MaterialTheme(colorScheme=darkColorScheme(primary=cyan,background=bg,surface=Color(0xFF122333))){
   Column(Modifier.fillMaxSize().background(bg).safeDrawingPadding().imePadding().padding(12.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){
    Row(verticalAlignment=Alignment.CenterVertically){Text("V2JRS / HUD",color=cyan,fontSize=25.sp,modifier=Modifier.weight(1f));TextButton(onClick={settings=true}){Text("Ayarlar")}}
    Text("SİMÜLASYON • ${stories[stage]}",color=yellow); LinearProgressIndicator(progress=energy/100f,modifier=Modifier.fillMaxWidth());Text("Enerji %$energy  |  Otonom: ${if(auto) "Açık" else "Kapalı"}")
    Box(Modifier.fillMaxWidth().height(230.dp).background(Color(0xFF0C1C2C))){
     Canvas(Modifier.fillMaxSize().pointerInput(stage){detectTapGestures { pos -> val dx=pos.x-size.width*.77f; val dy=pos.y-size.height*.5f; val r=minOf(size.width,size.height)*.19f; if(dx*dx+dy*dy<=r*r) advance() }}){
      for(i in 0..10){val p=i/10f;drawLine(cyan.copy(alpha=.09f),Offset(size.width*p,0f),Offset(size.width*p,size.height));drawLine(cyan.copy(alpha=.09f),Offset(0f,size.height*p),Offset(size.width,size.height*p))}
      val z=Offset(size.width*.77f,size.height*.5f);drawCircle(yellow.copy(alpha=.15f),size.minDimension*.19f*pulse,z);drawCircle(yellow,size.minDimension*.15f,z,style=Stroke(3f));val c=Offset(size.width*x,size.height*.5f);drawCircle(cyan.copy(alpha=.2f),size.minDimension*.16f*pulse,c);drawCircle(cyan,size.minDimension*.12f,c,style=Stroke(4f));drawCircle(if(target)yellow else cyan,size.minDimension*.055f,c)
     }
     Text("ÇEKİRDEK",color=cyan,modifier=Modifier.align(Alignment.TopStart).padding(12.dp));TextButton(onClick={advance()},modifier=Modifier.align(Alignment.BottomEnd)){Text("● BASARIM YERİ",color=yellow)}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){OutlinedButton(onClick={advance()},modifier=Modifier.weight(1f)){Text("Sarı alana git")};OutlinedButton(onClick={advance()},modifier=Modifier.weight(1f)){Text("Hikâyeyi ilerlet")}}
    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={listen()},modifier=Modifier.weight(1f)){Text("Mikrofon")};OutlinedButton(onClick={auto=!auto},modifier=Modifier.weight(1f)){Text(if(auto)"Otonom kapat" else "Otonom aç")}}
    if(voiceError.isNotEmpty())Text(voiceError,color=yellow)
    Text("CANLI OLAY KAYDI",color=cyan); Column(Modifier.fillMaxWidth().height(155.dp).background(Color(0xFF122333)).verticalScroll(rememberScrollState()).padding(10.dp)){log.asReversed().forEach{Text(it,modifier=Modifier.padding(bottom=6.dp),fontSize=13.sp)}}
    OutlinedTextField(value=input,onValueChange={input=it},label={Text("Komut yaz")},modifier=Modifier.fillMaxWidth());Button(onClick={command(input);input=""},modifier=Modifier.fillMaxWidth()){Text("Gönder")}
    Text(if(busy) "AI yanıt hazırlıyor..." else if(apiKey.isBlank()) "Yerel mod • API anahtarı gerekli" else "Çevrimiçi AI • ${model}",fontSize=11.sp,color=Color.LightGray)
   }
   if(settings) AlertDialog(onDismissRequest={settings=false},title={Text("AI ve ses ayarları")},text={Column(Modifier.verticalScroll(rememberScrollState())){Text("OpenRouter anahtarı (yalnızca bu oturumda tutulur)");OutlinedTextField(value=apiKey,onValueChange={apiKey=it},singleLine=true,visualTransformation=PasswordVisualTransformation(),label={Text("API anahtarı")});OutlinedTextField(value=model,onValueChange={model=it},singleLine=true,label={Text("Model kimliği")});Row(verticalAlignment=Alignment.CenterVertically){Text("Sesli yanıt",modifier=Modifier.weight(1f));Switch(checked=voice,onCheckedChange={voice=it;if(!it)tts?.stop()})};Text(if(ready)"Türkçe ses hazır" else "Türkçe ses motoru kullanılamıyor");Text("Hız");Slider(value=rate,onValueChange={rate=it},valueRange=.5f..1.5f);Text("Ses perdesi");Slider(value=pitch,onValueChange={pitch=it},valueRange=.5f..1.5f)}},confirmButton={TextButton(onClick={settings=false}){Text("Kapat")}})
  }
 }
 private fun askAI(key:String,model:String,history:List<Pair<String,String>>,question:String):String {
  val messages=JSONArray().put(JSONObject().put("role","system").put("content","Sen V2JRS adlı Türkçe, güvenli ve yardımcı bir AI asistansın. Uygulama dışı işlemler yaptığını iddia etme. Kullanıcıya anlaşılır cevap ver."))
  history.forEach{(role,content)->messages.put(JSONObject().put("role",role).put("content",content))}
  messages.put(JSONObject().put("role","user").put("content",question))
  val payload=JSONObject().put("model",model).put("messages",messages).put("max_tokens",700)
  val connection=URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpsURLConnection
  try {connection.requestMethod="POST";connection.instanceFollowRedirects=false;connection.connectTimeout=20000;connection.readTimeout=60000;connection.doOutput=true
   connection.setRequestProperty("Authorization","Bearer $key");connection.setRequestProperty("Content-Type","application/json")
   connection.outputStream.use{it.write(payload.toString().toByteArray(Charsets.UTF_8))}
   val status=connection.responseCode
   if(status !in 200..299) throw IllegalStateException("HTTP $status — anahtar, model veya kullanım limitini kontrol et.")
   val response=JSONObject(connection.inputStream.bufferedReader().use{it.readText()})
   return response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").ifBlank{"Model boş yanıt verdi."}
  } finally {connection.disconnect()}
 }

}
